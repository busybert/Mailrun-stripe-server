# MailRun Orlando – Stripe Checkout Server
This server creates Stripe Checkout sessions for your static website.

## 1️⃣ How to Deploy on Render
1. Go to https://render.com
2. Click “New +” → “Web Service”
3. Choose “Upload a .zip file”
4. Upload this mailrun-stripe-server.zip
5. Select Environment: Node
6. Build Command: (leave blank)
7. Start Command: npm start
8. Region: United States (recommended)
9. Add an Environment Variable:
   Key: STRIPE_SECRET_KEY
   Value: your Stripe test key (from https://dashboard.stripe.com/test/apikeys)
10. Click “Deploy Web Service”

Once it finishes, Render will give you a URL like:
https://mailrun-stripe.onrender.com

## 2️⃣ Connect to Your Site
In your MailRun HTML (Horizons/Hostinger), paste this snippet:

<script src="https://js.stripe.com/v3/"></script>
<script>
document.getElementById('checkout-button').addEventListener('click', async () => {
  const response = await fetch('https://mailrun-stripe.onrender.com/create-checkout-session', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      items: [{ price: "price_1SP71s2E8UrZzRbd8HSF8ile", quantity: 1 }]
    })
  });
  const session = await response.json();
  window.location.href = session.url;
});
</script>

Replace the “price_…” with your correct Stripe Price ID.

## 3️⃣ Test It
- Publish your site.
- Click your “Confirm Booking” or “Checkout” button.
- You’ll be redirected to Stripe’s test checkout page.
- Use test card number: 4242 4242 4242 4242.

Public test publishable key:
pk_test_51SKOopCSZzNce3wlf0vjhJgHo8Zd2hMtCrsmavClY00gVpf3rVc3BINL4We76WDzprXkya7vFtb0G9Y8TkBBfn4I00f5hfnWaC

✅ Success URL → https://mailrun-orlando.com/success.html
❌ Cancel URL → https://mailrun-orlando.com/cancel.html
